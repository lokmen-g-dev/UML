// publicationsData.js
const publicationsData = [
    {
      id: 1,
      photo: 'chemin/vers/photo1.jpg',
      titre: 'Publication 1',
      description: 'Description de la publication 1',
      date: '2023-06-07',
      evaluation: 4.5,
    },
    {
      id: 2,
      photo: 'chemin/vers/photo2.jpg',
      titre: 'Publication 2',
      description: 'Description de la publication 2',
      date: '2023-06-08',
      evaluation: 3.8,
    },
    // Ajoutez d'autres publications ici
  ];
  
  export default publicationsData;
  